def dao_nguoc_chuoi(chuoi):
    return chuoi[::-1]

def dem_so_tu(chuoi):
    return len(chuoi.split())
