from chuoi_utility import dao_nguoc_chuoi

chuoi = "Python rat de hoc"
print("Chuỗi đảo ngược:", dao_nguoc_chuoi(chuoi))
