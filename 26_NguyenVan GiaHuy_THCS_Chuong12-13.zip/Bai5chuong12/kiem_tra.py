import sys
sys.path.append("../thu_vien_chung")

from xu_ly_so import kiem_tra_so_nguyen_to

print(kiem_tra_so_nguyen_to(17))
