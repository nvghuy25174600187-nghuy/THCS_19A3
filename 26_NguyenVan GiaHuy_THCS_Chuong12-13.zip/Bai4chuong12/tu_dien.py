def lay_gia_tri(tu_dien, khoa):
    return tu_dien.get(khoa, "Không tồn tại")
