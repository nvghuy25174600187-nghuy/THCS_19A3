from du_lieu.danh_sach import sap_xep_tang_dan
from du_lieu.tu_dien import lay_gia_tri

ds = [5, 2, 9, 1]
td = {"a": 10, "b": 20}

print(sap_xep_tang_dan(ds))
print(lay_gia_tri(td, "b"))
