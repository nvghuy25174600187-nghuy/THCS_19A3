def sap_xep_tang_dan(danh_sach):
    return sorted(danh_sach)
