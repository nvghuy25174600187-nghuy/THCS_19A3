import math

def chu_vi_hinh_vuong(canh):
    return 4 * canh

def chu_vi_hinh_tron(ban_kinh):
    return 2 * math.pi * ban_kinh
