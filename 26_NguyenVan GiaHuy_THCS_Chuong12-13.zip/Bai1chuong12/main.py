from hinh_hoc import chu_vi_hinh_vuong, chu_vi_hinh_tron

print("Chu vi hình vuông:", chu_vi_hinh_vuong(5))
print("Chu vi hình tròn:", chu_vi_hinh_tron(3))
