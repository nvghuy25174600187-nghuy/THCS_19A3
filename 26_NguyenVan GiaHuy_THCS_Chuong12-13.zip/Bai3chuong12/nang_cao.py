import math

def luy_thua(co_so, so_mu):
    return co_so ** so_mu

def can_bac_hai(so):
    return math.sqrt(so)

