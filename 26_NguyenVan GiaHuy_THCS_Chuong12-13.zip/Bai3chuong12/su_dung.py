from may_tinh.co_ban import cong, tru
from may_tinh.nang_cao import luy_thua, can_bac_hai

print(cong(5, 3))
print(tru(10, 4))
print(luy_thua(2, 3))
print(can_bac_hai(16))
