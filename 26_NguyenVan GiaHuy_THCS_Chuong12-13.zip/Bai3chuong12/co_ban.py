def cong(a, b):
    return a + b

def tru(a, b):
    return a - b
